[CmdletBinding()]
param(
  [string]$AppName = "",
  [Alias("GucciAIPath")]
  [string]$AppPath = "",
  [string]$DataRoot = "",
  [switch]$SourceProject,
  [switch]$PatchStateConfig
)

$ErrorActionPreference = "Stop"
$PluginId = "openclaw-loop-runner"

function Resolve-AppName {
  param(
    [string]$InputName,
    [string]$InputPath
  )
  if ($InputName.Trim()) { return $InputName.Trim() }
  if ($InputPath.Trim()) {
    $full = [System.IO.Path]::GetFullPath($InputPath.Trim()).TrimEnd("\")
    if ((Split-Path -Leaf $full) -ieq "resources") {
      $full = Split-Path -Parent $full
    }
    $derived = Split-Path -Leaf $full
    if ($derived) { return $derived }
  }
  throw "Pass -AppName <application-name>, or pass -AppPath so the name can be derived from its directory."
}

function Resolve-AppPath {
  param(
    [string]$InputPath,
    [string]$ResolvedAppName
  )
  $candidates = @()
  if ($InputPath.Trim()) { $candidates += $InputPath.Trim() }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\$ResolvedAppName"),
    (Join-Path $env:ProgramFiles $ResolvedAppName),
    (Join-Path ${env:ProgramFiles(x86)} $ResolvedAppName),
    (Get-Location).Path
  )
  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    $full = [System.IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $full "resources")) { return $full }
    if ((Split-Path -Leaf $full) -ieq "resources" -and (Test-Path -LiteralPath $full)) { return (Split-Path -Parent $full) }
    if (Test-Path -LiteralPath (Join-Path $full "package.json")) { return $full }
  }
  throw "Cannot find $ResolvedAppName. Pass -AppPath <install-dir|resources-dir|source-dir>."
}

function Remove-Path {
  param([string]$Target)
  if (Test-Path -LiteralPath $Target) {
    Remove-Item -LiteralPath $Target -Recurse -Force
    Write-Host "[OK] Removed: $Target"
  }
}

$resolvedAppName = Resolve-AppName $AppName $AppPath
if (-not $DataRoot.Trim()) {
  $DataRoot = Join-Path $env:APPDATA "$resolvedAppName\openclaw"
}
$DataRoot = [System.IO.Path]::GetFullPath($DataRoot.Trim())
$root = Resolve-AppPath $AppPath $resolvedAppName
if ($SourceProject) {
  Remove-Path (Join-Path $root "openclaw-extensions\$PluginId")
} else {
  $resourcesDir = Join-Path $root "resources"
  if ((Split-Path -Leaf $root) -ieq "resources") { $resourcesDir = $root }
  Remove-Path (Join-Path $resourcesDir "cfmind\dist\extensions\$PluginId")
  Remove-Path (Join-Path $resourcesDir "cfmind\extensions\$PluginId")
}

if ($PatchStateConfig) {
  $configPath = Join-Path $DataRoot "state\openclaw.json"
  if (Test-Path -LiteralPath $configPath) {
    $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
    if (
      $json.PSObject.Properties["plugins"] -and
      $json.plugins.PSObject.Properties["entries"] -and
      $json.plugins.entries.PSObject.Properties[$PluginId]
    ) {
      $json.plugins.entries.PSObject.Properties.Remove($PluginId)
      $tmp = "$configPath.tmp"
      $json | ConvertTo-Json -Depth 80 | Set-Content -LiteralPath $tmp -Encoding UTF8
      Move-Item -LiteralPath $tmp -Destination $configPath -Force
      Write-Host "[OK] Removed plugin entry from state config."
    }
  }
}

Write-Host "[INFO] App name: $resolvedAppName"
Write-Host "[INFO] OpenClaw data root: $DataRoot"
Write-Host "[DONE] $PluginId uninstalled."
