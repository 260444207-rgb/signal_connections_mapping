# GucciAI OpenClaw Loop Runner Plugin Package

Installs `openclaw-loop-runner` into GucciAI without editing application source code.

## Install Into An Installed Application

Close the application, unzip this package, then run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -AppName "MyAssistant"
```

If auto-detection fails:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -AppName "MyAssistant" `
  -AppPath "C:\Users\<you>\AppData\Local\Programs\MyAssistant"
```

The application name is not hardcoded. For a renamed application:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -AppName "MyAssistant" `
  -AppPath "C:\Program Files\MyAssistant"
```

By default, OpenClaw data is resolved as
`%APPDATA%\<AppName>\openclaw`. Override it when the application uses a
different location:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -AppName "MyAssistant" `
  -AppPath "C:\Program Files\MyAssistant" `
  -DataRoot "D:\MyAssistantData\openclaw"
```

If `-AppName` is omitted but `-AppPath` is supplied, the application name
is derived from the install directory name.

`-GucciAIPath` remains available as a backward-compatible alias for
`-AppPath`.

For older builds that do not auto-enable newly discovered extensions:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -AppName "MyAssistant" `
  -PatchStateConfig
```

## Install Into Source Checkout

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -AppName "MyAssistant" `
  -AppPath "D:\github\MyAssistant" `
  -SourceProject
```

Then run from the GucciAI project root:

```powershell
npm run openclaw:extensions:local
npm run openclaw:precompile
```

## Per-Goal StateDir

Pass a stable root such as:

```text
%APPDATA%\<AppName>\openclaw\state\loop-runs
```

Each `goal` creates a fresh directory:

```text
<root>\runs\<run-id>\
```

The `goal` result returns the actual `state_dir`. Store that value on the GucciAI conversation/run record and use it for `run`, `snapshot`, and `check`.

Do not make concurrent conversations share the same returned run directory.

When calling the OpenClaw tool `OpenClawLoopGoal`, pass the GucciAI conversation id as `sessionId` when available. The runner will create a directory like:

```text
<root>\runs\<sessionId>-<timestamp>-<random>\
```

Set `reuseStateDir: true` only for legacy single-run behavior.

## UI Status

Render:

```text
<state_dir>\status_snapshot.json
```

Only `status == "complete"` means success. Treat `stopped_blocked`, `stopped_no_progress`, and `stopped_max_iterations` as terminal warning states.

## Uninstall

Use the same application name, install path, and optional data root used for
installation:

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1 `
  -AppName "MyAssistant" `
  -AppPath "C:\Program Files\MyAssistant" `
  -DataRoot "D:\MyAssistantData\openclaw" `
  -PatchStateConfig
```
