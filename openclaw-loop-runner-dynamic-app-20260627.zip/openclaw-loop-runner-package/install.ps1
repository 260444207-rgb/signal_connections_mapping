[CmdletBinding()]
param(
  [string]$AppName = "",
  [Alias("GucciAIPath")]
  [string]$AppPath = "",
  [string]$DataRoot = "",
  [switch]$SourceProject,
  [switch]$PatchStateConfig
)

$ErrorActionPreference = "Stop"
$PluginId = "openclaw-loop-runner"
$PackageRoot = Split-Path -Parent $PSCommandPath
$ExtensionSource = Join-Path $PackageRoot "extension\$PluginId"

function Resolve-AppName {
  param(
    [string]$InputName,
    [string]$InputPath
  )
  if ($InputName.Trim()) { return $InputName.Trim() }
  if ($InputPath.Trim()) {
    $full = [System.IO.Path]::GetFullPath($InputPath.Trim()).TrimEnd("\")
    if ((Split-Path -Leaf $full) -ieq "resources") {
      $full = Split-Path -Parent $full
    }
    $derived = Split-Path -Leaf $full
    if ($derived) { return $derived }
  }
  throw "Pass -AppName <application-name>, or pass -AppPath so the name can be derived from its directory."
}

function Resolve-AppPath {
  param(
    [string]$InputPath,
    [string]$ResolvedAppName
  )
  $candidates = @()
  if ($InputPath.Trim()) { $candidates += $InputPath.Trim() }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\$ResolvedAppName"),
    (Join-Path $env:ProgramFiles $ResolvedAppName),
    (Join-Path ${env:ProgramFiles(x86)} $ResolvedAppName),
    (Get-Location).Path
  )
  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    $full = [System.IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $full "resources")) { return $full }
    if ((Split-Path -Leaf $full) -ieq "resources" -and (Test-Path -LiteralPath $full)) { return (Split-Path -Parent $full) }
    if (Test-Path -LiteralPath (Join-Path $full "package.json")) { return $full }
  }
  throw "Cannot find $ResolvedAppName. Pass -AppPath <install-dir|resources-dir|source-dir>."
}

function Copy-Extension {
  param([string]$Destination)
  if (-not (Test-Path -LiteralPath (Join-Path $ExtensionSource "openclaw.plugin.json"))) {
    throw "Missing packaged extension: $ExtensionSource"
  }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null
  if (Test-Path -LiteralPath $Destination) {
    Remove-Item -LiteralPath $Destination -Recurse -Force
  }
  Copy-Item -LiteralPath $ExtensionSource -Destination $Destination -Recurse -Force
  Write-Host "[OK] Installed extension: $Destination"
}

function Patch-StateConfig {
  param([string]$ResolvedDataRoot)
  $configPath = Join-Path $ResolvedDataRoot "state\openclaw.json"
  if (-not (Test-Path -LiteralPath $configPath)) {
    Write-Host "[WARN] State config not found: $configPath"
    return
  }
  $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json
  if (-not $json.PSObject.Properties["plugins"]) {
    $json | Add-Member -MemberType NoteProperty -Name "plugins" -Value ([pscustomobject]@{})
  }
  if (-not $json.plugins.PSObject.Properties["entries"]) {
    $json.plugins | Add-Member -MemberType NoteProperty -Name "entries" -Value ([pscustomobject]@{})
  }
  $pluginConfig = [pscustomobject]@{ enabled = $true }
  if ($json.plugins.entries.PSObject.Properties[$PluginId]) {
    $json.plugins.entries.PSObject.Properties[$PluginId].Value = $pluginConfig
  } else {
    $json.plugins.entries | Add-Member -MemberType NoteProperty -Name $PluginId -Value $pluginConfig
  }
  $tmp = "$configPath.tmp"
  $json | ConvertTo-Json -Depth 80 | Set-Content -LiteralPath $tmp -Encoding UTF8
  Move-Item -LiteralPath $tmp -Destination $configPath -Force
  Write-Host "[OK] Patched state config: $configPath"
}

$resolvedAppName = Resolve-AppName $AppName $AppPath
if (-not $DataRoot.Trim()) {
  $DataRoot = Join-Path $env:APPDATA "$resolvedAppName\openclaw"
}
$DataRoot = [System.IO.Path]::GetFullPath($DataRoot.Trim())
$root = Resolve-AppPath $AppPath $resolvedAppName
if ($SourceProject) {
  if (-not (Test-Path -LiteralPath (Join-Path $root "package.json"))) {
    throw "SourceProject install requires a GucciAI source root with package.json."
  }
  Copy-Extension (Join-Path $root "openclaw-extensions\$PluginId")
  Write-Host "Next: npm run openclaw:extensions:local; npm run openclaw:precompile"
} else {
  $resourcesDir = Join-Path $root "resources"
  if ((Split-Path -Leaf $root) -ieq "resources") { $resourcesDir = $root }
  Copy-Extension (Join-Path $resourcesDir "cfmind\dist\extensions\$PluginId")
  Copy-Extension (Join-Path $resourcesDir "cfmind\extensions\$PluginId")
  Write-Host "Restart $resolvedAppName after installation."
}

if ($PatchStateConfig) { Patch-StateConfig $DataRoot }
Write-Host "[INFO] App name: $resolvedAppName"
Write-Host "[INFO] OpenClaw data root: $DataRoot"
Write-Host "[DONE] $PluginId installed."
