[CmdletBinding()]
param(
  [string]$GucciAIPath = "",
  [switch]$SourceProject,
  [switch]$PatchStateConfig,
  [switch]$Force
)

$ErrorActionPreference = "Stop"

$PluginId = "openclaw-loop-runner"
$PackageRoot = Split-Path -Parent $PSCommandPath
$ExtensionSource = Join-Path $PackageRoot "extension\$PluginId"

function Assert-ExtensionSource {
  if (-not (Test-Path -LiteralPath (Join-Path $ExtensionSource "openclaw.plugin.json"))) {
    throw "Missing packaged extension: $ExtensionSource"
  }
}

function Resolve-GucciAIPath {
  param([string]$InputPath)

  $candidates = @()
  if ($InputPath.Trim()) {
    $candidates += $InputPath.Trim()
  }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\GucciAI"),
    (Join-Path $env:ProgramFiles "GucciAI"),
    (Join-Path ${env:ProgramFiles(x86)} "GucciAI"),
    (Get-Location).Path
  )

  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    $full = [System.IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $full "resources")) {
      return $full
    }
    if ((Split-Path -Leaf $full) -ieq "resources" -and (Test-Path -LiteralPath $full)) {
      return (Split-Path -Parent $full)
    }
    if (Test-Path -LiteralPath (Join-Path $full "package.json")) {
      return $full
    }
  }

  throw "Cannot find GucciAI. Pass -GucciAIPath <install-dir|resources-dir|source-dir>."
}

function Copy-Extension {
  param([string]$Destination)

  $resolvedParent = [System.IO.Path]::GetFullPath((Split-Path -Parent $Destination))
  New-Item -ItemType Directory -Force -Path $resolvedParent | Out-Null

  if (Test-Path -LiteralPath $Destination) {
    if (-not $Force) {
      Write-Host "[INFO] Replacing existing plugin: $Destination"
    }
    Remove-Item -LiteralPath $Destination -Recurse -Force
  }

  Copy-Item -LiteralPath $ExtensionSource -Destination $Destination -Recurse -Force
  Write-Host "[OK] Installed extension: $Destination"
}

function Install-SourceProject {
  param([string]$Root)

  $extensionsDir = Join-Path $Root "openclaw-extensions"
  if (-not (Test-Path -LiteralPath (Join-Path $Root "package.json"))) {
    throw "Source project install requires a GucciAI source root with package.json: $Root"
  }
  Copy-Extension (Join-Path $extensionsDir $PluginId)
  Write-Host ""
  Write-Host "Next commands from the GucciAI project:"
  Write-Host "npm run openclaw:extensions:local"
  Write-Host "npm run openclaw:precompile"
}

function Install-ExeResources {
  param([string]$Root)

  $resourcesDir = Join-Path $Root "resources"
  if ((Split-Path -Leaf $Root) -ieq "resources") {
    $resourcesDir = $Root
  }
  if (-not (Test-Path -LiteralPath $resourcesDir)) {
    throw "Cannot find resources directory under: $Root"
  }

  $runtimeExtensions = Join-Path $resourcesDir "cfmind\dist\extensions"
  $discoveryExtensions = Join-Path $resourcesDir "cfmind\extensions"

  Copy-Extension (Join-Path $runtimeExtensions $PluginId)
  Copy-Extension (Join-Path $discoveryExtensions $PluginId)

  Write-Host ""
  Write-Host "[OK] Installed for GucciAI EXE resources."
  Write-Host "Restart GucciAI after installation."
}

function Patch-StateConfig {
  $configPath = Join-Path $env:APPDATA "GucciAI\openclaw\state\openclaw.json"
  if (-not (Test-Path -LiteralPath $configPath)) {
    Write-Host "[WARN] State config not found: $configPath"
    Write-Host "       Start GucciAI once, then re-run install.ps1 -PatchStateConfig if the plugin is not enabled."
    return
  }

  $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json -AsHashtable
  if (-not $json.ContainsKey("plugins") -or -not ($json["plugins"] -is [hashtable])) {
    $json["plugins"] = @{}
  }
  if (-not $json["plugins"].ContainsKey("entries") -or -not ($json["plugins"]["entries"] -is [hashtable])) {
    $json["plugins"]["entries"] = @{}
  }
  $json["plugins"]["entries"][$PluginId] = @{ enabled = $true }
  $tmp = "$configPath.tmp"
  $json | ConvertTo-Json -Depth 80 | Set-Content -LiteralPath $tmp -Encoding UTF8
  Move-Item -LiteralPath $tmp -Destination $configPath -Force
  Write-Host "[OK] Patched state config: $configPath"
}

Assert-ExtensionSource
$root = Resolve-GucciAIPath $GucciAIPath

if ($SourceProject) {
  Install-SourceProject $root
} else {
  Install-ExeResources $root
}

if ($PatchStateConfig) {
  Patch-StateConfig
}

Write-Host ""
Write-Host "[DONE] $PluginId installed."
