# App Integration

Use `snapshot` as the stable boundary between your exe and the loop runtime.

## Recommended Architecture

```text
Your exe
  -> starts goal/plan/run commands as child processes
  -> starts snapshot --watch as a lightweight status bridge
  -> renders status_snapshot.json in the UI

OpenClaw Loop Runner
  -> owns .openclaw-loop/
  -> writes prd.json/state.json/progress.md
  -> writes outputs/ and iterations/
  -> exports a UI-friendly snapshot
```

## Commands

Set these paths in the app:

```text
OPENCLAW_ROOT=C:\Users\xyj\AppData\Roaming\GucciAI\openclaw
RUNNER=%OPENCLAW_ROOT%\plugins\openclaw-loop-runner\scripts\openclaw_loop.ps1
STATE_DIR=<your project>\.openclaw-loop
SNAPSHOT_FILE=<your project>\.openclaw-loop\status_snapshot.json
```

In PowerShell:

```powershell
$OpenClawRoot = "C:\Users\xyj\AppData\Roaming\GucciAI\openclaw"
$Runner = "$OpenClawRoot\plugins\openclaw-loop-runner\scripts\openclaw_loop.ps1"
$StateDir = "<your project>\.openclaw-loop"
$SnapshotFile = "<your project>\.openclaw-loop\status_snapshot.json"
```

Create or replace a goal:

```powershell
powershell -ExecutionPolicy Bypass -File $Runner -StateDir $StateDir goal -Message "goal <user goal>" -Force
```

Run the loop:

```powershell
powershell -ExecutionPolicy Bypass -File $Runner -StateDir $StateDir run
```

Export a UI snapshot:

```powershell
powershell -ExecutionPolicy Bypass -File $Runner -StateDir $StateDir snapshot --out-file $SnapshotFile
```

Start a live UI bridge:

```powershell
powershell -ExecutionPolicy Bypass -File $Runner -StateDir $StateDir snapshot --out-file $SnapshotFile --watch --interval-seconds 1 --stop-on-terminal
```

If your app can keep child processes running, start `run` and `snapshot --watch` in the background. The UI reads `status_snapshot.json` whenever the file changes. If your app cannot keep a background process, trigger `run --max-iterations 1` repeatedly and refresh `snapshot` after each step.

`snapshot --watch` writes the JSON file with an atomic replace so the UI does not read a partially written file.

## Snapshot Shape

```json
{
  "schemaVersion": 1,
  "generatedAt": "2026-06-23T10:00:00",
  "stateDir": ".openclaw-loop",
  "goal": "user goal",
  "status": "running",
  "counts": {
    "todo": 2,
    "done": 1,
    "blocked": 1
  },
  "state": {},
  "tasks": [
    {
      "id": "T001",
      "title": "Task title",
      "status": "done",
      "attempts": 1,
      "maxAttempts": 3,
      "outputFile": ".openclaw-loop/outputs/T001.jsonl",
      "outputExists": true,
      "evaluation": {
        "status": "PASS",
        "passed": true
      }
    }
  ],
  "progressTail": "...",
  "latestIterationPrompts": [],
  "uiHints": {}
}
```

## UI Mapping

```text
running, awaiting_goal_prompt       show active/running
complete                            show success
stopped_no_progress                 show warning: repeated failures
stopped_max_iterations              show warning: iteration limit reached
stopped_blocked                     show warning/error: blocked tasks need attention
failed, blocked task status         show task-level retry/failure state
```

The app should treat chat text as informational only. A task is complete only when the snapshot task evaluation is `PASS` and the task status is `done`.

## C# Bridge

For WinForms/WPF/.NET desktop apps, copy this helper into your app:

```text
examples/csharp/OpenClawLoopBridge.cs
```

Minimal usage:

```csharp
var bridge = new OpenClawLoopBridge(
    @"C:\Users\xyj\AppData\Roaming\GucciAI\openclaw",
    projectDir
);

bridge.SnapshotChanged += snapshot =>
{
    var status = snapshot.RootElement.GetProperty("status").GetString();
    var tasks = snapshot.RootElement.GetProperty("tasks");
    // Marshal to the UI thread, then update status labels, task table, and progress log.
};

bridge.CreateGoal(userGoal, force: true);
bridge.StartSnapshotWatch();
bridge.StartLoop();
```

On app shutdown, call:

```csharp
bridge.Dispose();
```
