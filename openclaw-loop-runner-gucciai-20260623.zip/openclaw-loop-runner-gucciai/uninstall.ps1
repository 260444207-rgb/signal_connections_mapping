[CmdletBinding()]
param(
  [string]$GucciAIPath = "",
  [switch]$SourceProject,
  [switch]$PatchStateConfig
)

$ErrorActionPreference = "Stop"

$PluginId = "openclaw-loop-runner"

function Resolve-GucciAIPath {
  param([string]$InputPath)

  $candidates = @()
  if ($InputPath.Trim()) {
    $candidates += $InputPath.Trim()
  }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\GucciAI"),
    (Join-Path $env:ProgramFiles "GucciAI"),
    (Join-Path ${env:ProgramFiles(x86)} "GucciAI"),
    (Get-Location).Path
  )

  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    $full = [System.IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $full "resources")) {
      return $full
    }
    if ((Split-Path -Leaf $full) -ieq "resources" -and (Test-Path -LiteralPath $full)) {
      return (Split-Path -Parent $full)
    }
    if (Test-Path -LiteralPath (Join-Path $full "package.json")) {
      return $full
    }
  }

  throw "Cannot find GucciAI. Pass -GucciAIPath <install-dir|resources-dir|source-dir>."
}

function Remove-IfInside {
  param([string]$PathToRemove, [string]$AllowedRoot)

  $resolvedRoot = [System.IO.Path]::GetFullPath($AllowedRoot)
  if (-not (Test-Path -LiteralPath $PathToRemove)) {
    return
  }
  $resolvedTarget = [System.IO.Path]::GetFullPath($PathToRemove)
  if (-not $resolvedTarget.StartsWith($resolvedRoot)) {
    throw "Refusing to remove path outside allowed root: $resolvedTarget"
  }
  Remove-Item -LiteralPath $resolvedTarget -Recurse -Force
  Write-Host "[OK] Removed: $resolvedTarget"
}

function Uninstall-SourceProject {
  param([string]$Root)
  Remove-IfInside (Join-Path $Root "openclaw-extensions\$PluginId") $Root
}

function Uninstall-ExeResources {
  param([string]$Root)

  $resourcesDir = Join-Path $Root "resources"
  if ((Split-Path -Leaf $Root) -ieq "resources") {
    $resourcesDir = $Root
  }
  Remove-IfInside (Join-Path $resourcesDir "cfmind\dist\extensions\$PluginId") $resourcesDir
  Remove-IfInside (Join-Path $resourcesDir "cfmind\extensions\$PluginId") $resourcesDir
}

function Unpatch-StateConfig {
  $configPath = Join-Path $env:APPDATA "GucciAI\openclaw\state\openclaw.json"
  if (-not (Test-Path -LiteralPath $configPath)) {
    Write-Host "[INFO] State config not found: $configPath"
    return
  }

  $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json -AsHashtable
  if (
    $json.ContainsKey("plugins") -and
    ($json["plugins"] -is [hashtable]) -and
    $json["plugins"].ContainsKey("entries") -and
    ($json["plugins"]["entries"] -is [hashtable]) -and
    $json["plugins"]["entries"].ContainsKey($PluginId)
  ) {
    $json["plugins"]["entries"].Remove($PluginId)
    $tmp = "$configPath.tmp"
    $json | ConvertTo-Json -Depth 80 | Set-Content -LiteralPath $tmp -Encoding UTF8
    Move-Item -LiteralPath $tmp -Destination $configPath -Force
    Write-Host "[OK] Removed plugin entry from state config: $configPath"
  }
}

$root = Resolve-GucciAIPath $GucciAIPath
if ($SourceProject) {
  Uninstall-SourceProject $root
} else {
  Uninstall-ExeResources $root
}

if ($PatchStateConfig) {
  Unpatch-StateConfig
}

Write-Host ""
Write-Host "[DONE] $PluginId uninstalled."
