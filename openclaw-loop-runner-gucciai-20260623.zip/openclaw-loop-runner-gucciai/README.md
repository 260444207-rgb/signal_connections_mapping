# GucciAI OpenClaw Loop Runner Plugin Package

This package installs `openclaw-loop-runner` into a GucciAI desktop installation without editing the application source code.

## Package Contents

```text
extension/openclaw-loop-runner/   compiled OpenClaw extension + bundled runner
install.ps1                       installer
uninstall.ps1                     uninstaller
```

## Install Into An Installed GucciAI EXE

Close GucciAI first.

Run PowerShell from this package directory:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

If the installer cannot find GucciAI automatically, pass the installation directory or resources directory:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -GucciAIPath "C:\Users\<you>\AppData\Local\Programs\GucciAI"
```

or:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -GucciAIPath "C:\Users\<you>\AppData\Local\Programs\GucciAI\resources"
```

The installer copies the plugin to:

```text
<GucciAI>\resources\cfmind\dist\extensions\openclaw-loop-runner
```

It also mirrors the manifest to:

```text
<GucciAI>\resources\cfmind\extensions\openclaw-loop-runner
```

for GucciAI builds that discover extensions from that path.

## Enable In Older Builds

Newer GucciAI builds can auto-enable the extension when it is present. If your installed exe does not yet auto-enable it, run:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 -PatchStateConfig
```

This patches:

```text
%APPDATA%\GucciAI\openclaw\state\openclaw.json
```

and adds:

```json
{
  "plugins": {
    "entries": {
      "openclaw-loop-runner": {
        "enabled": true
      }
    }
  }
}
```

If GucciAI later regenerates `openclaw.json`, run the installer with `-PatchStateConfig` again.

## Install Into A Source Checkout

For a developer checkout:

```powershell
powershell -ExecutionPolicy Bypass -File .\install.ps1 `
  -GucciAIPath "D:\github\GucciAI" `
  -SourceProject
```

Then run from the GucciAI project:

```powershell
npm run openclaw:extensions:local
npm run openclaw:precompile
```

## UI Status

The plugin writes a UI-friendly status file:

```text
<StateDir>\status_snapshot.json
```

Useful fields:

```text
status
counts
tasks[].status
tasks[].attempts
tasks[].evaluation
progressTail
latestIterationPrompts
```

Only `status == "complete"` means success. Treat `stopped_blocked`, `stopped_no_progress`, and `stopped_max_iterations` as terminal warning states.

## Uninstall

```powershell
powershell -ExecutionPolicy Bypass -File .\uninstall.ps1
```

Use `-GucciAIPath` if auto-detection fails.
