[CmdletBinding()]
param(
  [string]$GucciAIPath = "",
  [switch]$SourceProject,
  [switch]$PatchStateConfig
)

$ErrorActionPreference = "Stop"
$PluginId = "openclaw-loop-runner"

function Resolve-GucciAIPath {
  param([string]$InputPath)
  $candidates = @()
  if ($InputPath.Trim()) { $candidates += $InputPath.Trim() }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\GucciAI"),
    (Join-Path $env:ProgramFiles "GucciAI"),
    (Join-Path ${env:ProgramFiles(x86)} "GucciAI"),
    (Get-Location).Path
  )
  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    $full = [System.IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $full "resources")) { return $full }
    if ((Split-Path -Leaf $full) -ieq "resources" -and (Test-Path -LiteralPath $full)) { return (Split-Path -Parent $full) }
    if (Test-Path -LiteralPath (Join-Path $full "package.json")) { return $full }
  }
  throw "Cannot find GucciAI. Pass -GucciAIPath <install-dir|resources-dir|source-dir>."
}

function Remove-Path {
  param([string]$Target)
  if (Test-Path -LiteralPath $Target) {
    Remove-Item -LiteralPath $Target -Recurse -Force
    Write-Host "[OK] Removed: $Target"
  }
}

$root = Resolve-GucciAIPath $GucciAIPath
if ($SourceProject) {
  Remove-Path (Join-Path $root "openclaw-extensions\$PluginId")
} else {
  $resourcesDir = Join-Path $root "resources"
  if ((Split-Path -Leaf $root) -ieq "resources") { $resourcesDir = $root }
  Remove-Path (Join-Path $resourcesDir "cfmind\dist\extensions\$PluginId")
  Remove-Path (Join-Path $resourcesDir "cfmind\extensions\$PluginId")
}

if ($PatchStateConfig) {
  $configPath = Join-Path $env:APPDATA "GucciAI\openclaw\state\openclaw.json"
  if (Test-Path -LiteralPath $configPath) {
    $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json -AsHashtable
    if ($json.ContainsKey("plugins") -and ($json["plugins"] -is [hashtable]) -and $json["plugins"].ContainsKey("entries") -and ($json["plugins"]["entries"] -is [hashtable])) {
      $json["plugins"]["entries"].Remove($PluginId)
      $tmp = "$configPath.tmp"
      $json | ConvertTo-Json -Depth 80 | Set-Content -LiteralPath $tmp -Encoding UTF8
      Move-Item -LiteralPath $tmp -Destination $configPath -Force
      Write-Host "[OK] Removed plugin entry from state config."
    }
  }
}

Write-Host "[DONE] $PluginId uninstalled."
