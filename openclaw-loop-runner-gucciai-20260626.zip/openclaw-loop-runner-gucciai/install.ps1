[CmdletBinding()]
param(
  [string]$GucciAIPath = "",
  [switch]$SourceProject,
  [switch]$PatchStateConfig
)

$ErrorActionPreference = "Stop"
$PluginId = "openclaw-loop-runner"
$PackageRoot = Split-Path -Parent $PSCommandPath
$ExtensionSource = Join-Path $PackageRoot "extension\$PluginId"

function Resolve-GucciAIPath {
  param([string]$InputPath)
  $candidates = @()
  if ($InputPath.Trim()) { $candidates += $InputPath.Trim() }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA "Programs\GucciAI"),
    (Join-Path $env:ProgramFiles "GucciAI"),
    (Join-Path ${env:ProgramFiles(x86)} "GucciAI"),
    (Get-Location).Path
  )
  foreach ($candidate in $candidates) {
    if (-not $candidate) { continue }
    $full = [System.IO.Path]::GetFullPath($candidate)
    if (Test-Path -LiteralPath (Join-Path $full "resources")) { return $full }
    if ((Split-Path -Leaf $full) -ieq "resources" -and (Test-Path -LiteralPath $full)) { return (Split-Path -Parent $full) }
    if (Test-Path -LiteralPath (Join-Path $full "package.json")) { return $full }
  }
  throw "Cannot find GucciAI. Pass -GucciAIPath <install-dir|resources-dir|source-dir>."
}

function Copy-Extension {
  param([string]$Destination)
  if (-not (Test-Path -LiteralPath (Join-Path $ExtensionSource "openclaw.plugin.json"))) {
    throw "Missing packaged extension: $ExtensionSource"
  }
  New-Item -ItemType Directory -Force -Path (Split-Path -Parent $Destination) | Out-Null
  if (Test-Path -LiteralPath $Destination) {
    Remove-Item -LiteralPath $Destination -Recurse -Force
  }
  Copy-Item -LiteralPath $ExtensionSource -Destination $Destination -Recurse -Force
  Write-Host "[OK] Installed extension: $Destination"
}

function Patch-StateConfig {
  $configPath = Join-Path $env:APPDATA "GucciAI\openclaw\state\openclaw.json"
  if (-not (Test-Path -LiteralPath $configPath)) {
    Write-Host "[WARN] State config not found: $configPath"
    return
  }
  $json = Get-Content -LiteralPath $configPath -Raw | ConvertFrom-Json -AsHashtable
  if (-not $json.ContainsKey("plugins") -or -not ($json["plugins"] -is [hashtable])) { $json["plugins"] = @{} }
  if (-not $json["plugins"].ContainsKey("entries") -or -not ($json["plugins"]["entries"] -is [hashtable])) { $json["plugins"]["entries"] = @{} }
  $json["plugins"]["entries"][$PluginId] = @{ enabled = $true }
  $tmp = "$configPath.tmp"
  $json | ConvertTo-Json -Depth 80 | Set-Content -LiteralPath $tmp -Encoding UTF8
  Move-Item -LiteralPath $tmp -Destination $configPath -Force
  Write-Host "[OK] Patched state config: $configPath"
}

$root = Resolve-GucciAIPath $GucciAIPath
if ($SourceProject) {
  if (-not (Test-Path -LiteralPath (Join-Path $root "package.json"))) {
    throw "SourceProject install requires a GucciAI source root with package.json."
  }
  Copy-Extension (Join-Path $root "openclaw-extensions\$PluginId")
  Write-Host "Next: npm run openclaw:extensions:local; npm run openclaw:precompile"
} else {
  $resourcesDir = Join-Path $root "resources"
  if ((Split-Path -Leaf $root) -ieq "resources") { $resourcesDir = $root }
  Copy-Extension (Join-Path $resourcesDir "cfmind\dist\extensions\$PluginId")
  Copy-Extension (Join-Path $resourcesDir "cfmind\extensions\$PluginId")
  Write-Host "Restart GucciAI after installation."
}

if ($PatchStateConfig) { Patch-StateConfig }
Write-Host "[DONE] $PluginId installed."
