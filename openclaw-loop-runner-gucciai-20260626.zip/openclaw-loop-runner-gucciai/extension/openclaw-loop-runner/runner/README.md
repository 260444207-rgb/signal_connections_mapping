# OpenClaw Loop Runner

OpenClaw Loop Runner is a local Codex/OpenClaw plugin pattern for long-running OpenClaw-style work.

Install instructions: see `INSTALL_OPENCLAW.md`.

It turns a vague long task into a loop:

```text
state init -> pick task -> fresh worker prompt -> output_contract file -> evaluator -> state update -> continue or stop
```

The important contract is simple: a worker/subagent is not done because it replied in chat. It is done only when it writes the required artifact and the supervisor verifies it.

## Files

```text
openclaw-loop-runner/
├── .codex-plugin/plugin.json
├── openclaw.plugin.yaml
├── templates/
│   ├── prd.json
│   ├── progress.md
│   └── loop_prompt.md
├── runtime/openclaw_loop_runner/
│   ├── loop_controller.py
│   ├── task_store.py
│   ├── agent_runner.py
│   ├── evaluator.py
│   └── progress_writer.py
├── skills/openclaw-loop-runner/SKILL.md
└── scripts/
    ├── openclaw_loop.py
    └── openclaw_loop_guard.py
```

## Runtime CLI

Initialize state:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop init
```

Generate anchor files from a user description:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop plan `
  -Description "your long task description"
```

Goal mode, one-step:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop goal `
  -Message "goal your long task description"
```

Each `goal` creates a fresh run directory under `.openclaw-loop/runs/<run-id>/` and returns the actual `state_dir`. Use that returned `state_dir` for `run`, `snapshot`, and `check` when multiple conversations may run concurrently. Passing the root `.openclaw-loop` to `status` or `snapshot` follows `.openclaw-loop/current_run.json` and shows the latest run only.

Goal mode, two-step:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop goal -Message "goal"
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop goal `
  -Message "your long task description"
```

If OpenClaw supports chat middleware, pass every user message to `loop.goal --message "{message}"`. When it returns `NOOP`, continue to the default agent; when it returns `AWAITING_GOAL_PROMPT` or `OK`, the message was handled by goal mode.

For longer descriptions:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop plan `
  -DescriptionFile .\task-description.md `
  -Force
```

Check status:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop status
```

Export an app/UI snapshot:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop snapshot `
  --out-file .openclaw-loop/status_snapshot.json
```

Desktop apps can run `snapshot --watch` as a lightweight status bridge:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop snapshot `
  --out-file .openclaw-loop/status_snapshot.json `
  --watch `
  --interval-seconds 1 `
  --stop-on-terminal
```

The exported JSON includes loop status, task counts, task attempts, evaluator results, blocked tasks, recent progress, and latest worker prompt files. It is written with atomic replace for safer UI reads.

For WinForms/WPF/.NET desktop apps, see:

```text
examples/csharp/OpenClawLoopBridge.cs
```

Pick next runnable task:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop next
```

Run the loop. Without `--agent-command`, it writes dispatch prompts under `.openclaw-loop/iterations/` and evaluates the declared output contracts. With an OpenClaw agent command, placeholders are available:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop run `
  --agent-command "openclaw agent run --prompt-file {prompt_file}"
```

Available placeholders:

```text
{prompt_file}
{task_id}
{output_file}
```

Check all task output contracts:

```bash
powershell -ExecutionPolicy Bypass -File .\scripts\openclaw_loop.ps1 -StateDir .openclaw-loop check
```

## Standalone Guard Script

Validate a task plan and merge successful worker outputs:

```bash
python scripts/openclaw_loop_guard.py check \
  --plan <task_plan.json> \
  --merged-output <merged_output.jsonl> \
  --report <loop_gate_report.json> \
  --rerun-plan <failed_task_rerun_plan.md>
```

Expected task shape:

```json
{
  "tasks": [
    {
      "task_id": "TASK_01",
      "task_json": "path/to/TASK_01.json",
      "line_ids": ["L1", "L2"],
      "output_contract": {
        "output_file": "path/to/TASK_01.jsonl",
        "format": "jsonl",
        "expected_line_ids": ["L1", "L2"]
      }
    }
  ]
}
```

If any output file is missing, malformed, incomplete, duplicated, or has extra IDs, the script fails and writes a rerun plan.

## Stop Conditions

The runtime exits on these conditions:

```text
complete                 all tasks are done or skipped
stopped_no_progress      consecutive failed evaluations reached the configured limit
stopped_max_iterations   loop hit the maximum iteration limit
stopped_blocked          no runnable tasks remain, but unfinished/blocked tasks still exist
```

`stopped_blocked` prevents blocked work from being reported as complete.
