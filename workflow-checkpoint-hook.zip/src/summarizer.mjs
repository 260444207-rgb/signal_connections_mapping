export async function completeSummary(config, request) {
  if (!config?.baseUrl || !config.model)
    throw Error('SUMMARIZER_NOT_CONFIGURED');
  const base = new URL(config.baseUrl);
  if (base.protocol !== 'https:' && !(base.protocol === 'http:' && ['localhost', '127.0.0.1', '[::1]'].includes(base.hostname)))
    throw Error('SUMMARIZER_URL_REQUIRES_HTTPS');
  const key = process.env[config.apiKeyEnv || 'WORKFLOW_CHECKPOINT_API_KEY'];
  if (!key)
    throw Error('SUMMARIZER_API_KEY_MISSING');
  const response = await fetch(config.baseUrl.replace(/\/$/, '') + '/chat/completions', {
    method: 'POST', signal: request.signal,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + key },
    body: JSON.stringify({ model: config.model, temperature: 0,
      messages: [{ role: 'system', content: request.systemPrompt }, ...request.messages] }),
  });
  if (!response.ok)
    throw Error('SUMMARIZER_HTTP_' + response.status);
  const result = await response.json();
  const text = result.choices?.[0]?.message?.content;
  if (typeof text !== 'string')
    throw Error('SUMMARIZER_INVALID_RESPONSE');
  return { text };
}
