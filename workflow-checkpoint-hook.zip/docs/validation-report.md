# 验证报告

验证日期：2026-09-21。交付形式为独立 HOOK.md + handler.js + Node 配套脚本。验证使用 Node v24.16.0，目标运行时为 OpenClaw 2026.9.2。

## 自动验证结果

在交付目录执行 `npm test`，共 **33 项测试，33 通过，0 失败、0 跳过**。测试运行器报告耗时约 1.97 秒（不含 npm 启动）。

| 测试文件 | 项数 | 验证范围 |
| --- | ---: | --- |
| tests/coordinator.test.mjs | 15 | 三阶段流转、阶段与会话隔离、重复提交、归档/存储失败、完整记录先于摘要、状态持久化及投递恢复 |
| tests/hook.test.mjs | 12 | Hook 注入与清理、可信 run 绑定、等待源 run 结束、原会话 reset/发送顺序、终点、错误阻断、incognito 拒绝、Skill 快照 |
| tests/process.test.mjs | 1 | 真实默认 Hook、并发 CLI、后台子进程、loopback HTTP 摘要、SQLite/归档、哈希、保存 prompt 原样发送、终点停止、状态查询和子进程退出 |
| tests/recovery.test.mjs | 5 | 使用真实测试子进程 PID 验证已退出 worker 可恢复 pending 卡点；活进程、不确定投递、未持久卡点、更新 run 均拒绝 |

跨进程测试运行真正的 checkpoint.mjs 和后台 worker，没有替换业务实现。它只把 OpenClaw SDK/Gateway 和摘要模型换成可观察的测试服务：Gateway 以临时文件记录调用，本地 HTTP 返回固定结构化摘要。归档写入、进程调度、哈希、SQLite 事务和 prompt 传递使用真实实现。

包检查另确认 18 个 JS/MJS 文件可通过 Node 语法检查，5 个 JSON 文件可解析，Markdown 本地链接目标均存在；包内没有插件 manifest 或 api.registerTool/api.on 注册调用。

## 需求与证据对应

| 要求 | 当前证据 | 结论范围 |
| --- | --- | --- |
| 不依赖自然语言识别卡点 | request 参数验证、workflow 配置与重复/越序测试 | 机器协议通过 |
| 阶段不是写死 A/C | 三阶段核心测试、两阶段跨进程测试、三阶段业务示例 | 任意配置的线性阶段通过 |
| 完成源轮再归档完整可见记录 | 跨进程测试在源结束前确认无摘要/RPC；结束前最后一条消息也进入归档 | 公开 transcript 提供的记录通过 |
| 先归档再摘要和 reset | 摘要服务与 reset fixture 在调用时检查文件；归档/存储失败用例 | 本地顺序与失败阻断通过 |
| 提取原始用户输入、完成状态和产物 | prompt 与 checkpoint 断言，下一阶段排除自动恢复 prompt，阶段产物引用测试 | 结构与数据传递通过；模型语义质量需真实模型演练 |
| 原会话上下文重置后续跑 | 校验同 key/id、新 revision、reset 在 agent 之前、message 等于保存文件 | SDK 调用合同及过程通过；真实 Gateway 部署待演练 |
| reset 后仍能找到原 Skill | workflowSkills 快照、路径和 SHA256 测试 | 配置 Skill 的恢复引用通过 |
| 阶段幂等、隔离 | 并发 CLI 两次请求只产生一个 job/一次 reset；多工作流测试 | 已覆盖场景通过 |
| 崩溃后恢复 | 真实旧 worker 退出后恢复已持久 pending 卡点，复用原归档和 prompt | 安全恢复通过；不自动重放不确定外部动作 |
| 独立 Hook，不使用插件形态 | HOOK.md 元数据、handler 默认入口、无插件 manifest/注册 API | 包结构满足 |
| 详细说明及可复制示例 | usage-guide、skill-checkpoint-adaptation、examples 中 Skill/配置/输入/产物 | 文件已提供；静态样本不是实际业务运行证明 |

## 此次验证发现并修复的问题

1. 终点卡点应标记 done，不应因没有下一轮投递而误报 held。
2. OpenClaw incognito 的 reset 会删除会话；现在 bootstrap、worker 和最终 reset 前拒绝此类型。
3. 重置后需要找回原 Skill；新增 workflowSkills 映射、归档副本、恢复引用及 reset 前哈希校验。
4. 仅有 working 状态不能判断旧 worker 是否存活；新增 PID 记录和受限 recover 命令，拒绝重放已开始的投递。
5. 恢复重复 checkpoint 时，以实际 delivery 状态决定 job 是否 done，不能把 duplicate 返回值误当成成功发送。

## 未作出的验证结论

此次未连接用户的真实 Gateway、未使用实际模型密钥，也未 reset 用户当前业务会话。没有验证宿主界面历史显示、生产环境权限/认证、真实摘要语义质量和真实模型是否始终遵守 Skill 的停止约定。

真实部署验收步骤已列在 [详细使用说明](usage-guide.md) 与 [演练示例](../examples/README.md)。需要以实际三轮记录、两个非终点 reset 回执、同 key/id 的新 revision 及最终产物作为部署通过证据。不要用测试 fixture 或示例产物替代它。
