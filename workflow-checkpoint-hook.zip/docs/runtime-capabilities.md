# 独立 Hook 的运行时能力核查

核查对象是 npm 发布包 `openclaw@2026.9.2`，Node `>=24.15.0 <25`。实现只导入该包公开 exports，不导入以下列出的散列 dist 文件，也不修改 OpenClaw 核心。散列文件名仅作为本次源码核查的定位证据。

## 用户要求与原方案的调整

原方案提出 native plugin、自定义 workflow_checkpoint 工具和 agent_end 插件事件。用户后来明确要求改为独立 Hook，并接受“HOOK.md + 配套脚本”。因此入口改为现有 exec 工具运行结构化 CLI，生命周期改为公开观察接口；归档、显式阶段协议、幂等、原会话重置与续跑要求保留。

用户还明确要求 reset 原会话，因此没有采用只注入摘要而保留旧模型上下文的 fallback，也没有创建 child session 或摘要 Agent 会话。

## 能力表

| 能力 | 状态 | 本实现与依据 |
| --- | --- | --- |
| 文件 Hook 发现与执行 | SUPPORTED | HOOK.md + 默认导出的 handler.js；包内 docs/automation/hooks.md、docs/cli/hooks.md |
| 独立 Hook 注册新模型工具 | UNSUPPORTED | 文件 Hook 没有 plugin register(api)；通过现有 exec 调用 checkpoint.mjs |
| 独立 Hook 的 agent_end 事件 | UNSUPPORTED | 不在文件 Hook 事件表内，HOOK.md 没有声明它 |
| 注入当前轮次绑定 | SUPPORTED | agent:bootstrap 可修改 bootstrapFiles；上下文携带 agentId/sessionId/sessionKey |
| 观察实际 run 生命周期 | SUPPORTED | openclaw/plugin-sdk/agent-harness-runtime 的 onAgentEvent；进程共享 listener，生命周期携带实际身份 |
| 获取当前会话及代次 | SUPPORTED | session-store-runtime 的同步 getSessionEntry({sessionKey,agentId,readConsistency:'latest'}) |
| 读取公开完整消息与事件 | SUPPORTED | session-transcript-runtime 的 readVisibleSessionTranscriptMessageEntries、readSessionTranscriptEvents |
| 读取服务端隐藏推理/未持久化内存 | UNSUPPORTED | 不属于公开 transcript 能力，不能声称已归档这些内容 |
| 确认源 run 结束 | SUPPORTED | 先观察生命周期，再通过公开 Gateway agent.wait 确认 status=ok |
| 重置普通会话上下文 | SUPPORTED | sessions.reset 保留已有 key/id，更新 lifecycleRevision；返回值必须验证 |
| 重置 incognito 并保留身份 | UNSUPPORTED | 其 reset 会删除会话。公开 session-key-runtime 的 isIncognitoSessionKey 与 entry.incognito 用于操作前拒绝 |
| 同 key/id 提交下一轮 | SUPPORTED | Gateway agent；带 expectedExistingSessionId、idempotencyKey，message 取自保存的 prompt |
| reset 的原子代次条件 | UNSUPPORTED | 无 expectedRevision compare-and-swap；已有检查仍无法消除最后一瞬间的并发竞态 |
| 硬阻止源 Agent 再调用工具 | UNSUPPORTED | 文件 Hook 无 before_tool_call 拦截器；必须由 Skill 遵守 accepted 后结束的规则 |
| 自动摘要 | PARTIAL | 脚本使用单独配置的 OpenAI-compatible HTTP 接口，不自动继承 Agent OAuth/model runtime |
| 崩溃后恢复尚未投递的卡点 | SUPPORTED | recover 命令检查已退出 worker、结束的源 run、持久化 pending 投递，再重新调度 |
| 不确定 reset/发送的自动重放 | UNSUPPORTED | 为避免重复 reset/执行，dispatching/held/submitted 投递拒绝自动重放；需查真实 Gateway 状态 |

## 核查的公开调用

下列签名在当前包的公开导出、声明或实现中核实：

```js
sdk.onAgentEvent(event => { /* lifecycle: start/end/error + run identity */ });
sdk.getSessionEntry({ sessionKey, agentId, readConsistency: 'latest' });
await sdk.readVisibleSessionTranscriptMessageEntries({ sessionKey, sessionId, agentId });
await sdk.readSessionTranscriptEvents({ sessionKey, sessionId, agentId });
await sdk.callGatewayFromCli('agent.wait', { timeout: '20000' },
  { runId, timeoutMs: 15000 }, { progress: false, scopes: ['operator.read'] });
```

重置、发送是有副作用的能力；不要把下面的签名示意当作应该手动运行的命令：

```js
await sdk.callGatewayFromCli('sessions.reset', { timeout: '30000' },
  { key: sessionKey, agentId, reason: 'reset' },
  { progress: false, scopes: ['operator.admin'] });
await sdk.callGatewayFromCli('agent', { timeout: '15000', expectFinal: false },
  { sessionKey, agentId, expectedExistingSessionId: sessionId,
    idempotencyKey, message: savedPrompt, deliver: false },
  { progress: false, expectFinal: false, scopes: ['operator.write'] });
```

对应源码定位：`dist/agent-events-CoxiItUi.js`（共享订阅及身份）、`dist/session-store-runtime-Btld46Zi.js`（同步读取）、`dist/session-entry-projection-1R43v9cM.js`（代次和 incognito）、`dist/session-transcript-runtime-unJeSCUF.js`（消息及事件）、`dist/session-reset-service-DsSXKjai.js`（普通 reset 与临时会话删除）。生产入口统一由 src/sdk.mjs 解析公共子路径，版本差异由适配器隔离。

## 升级检查

本实现会拒绝未经核查的 OpenClaw 版本。升级时重新核查上述导出、Hook 事件、run 身份、transcript 范围、reset key/id/revision 语义和 Gateway scopes；修改版本闸门前运行测试，再用专用真实任务完成 examples 中的部署演练。替身测试通过不能证明新版本已经兼容。
